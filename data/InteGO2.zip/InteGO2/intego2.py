#-*- coding: UTF-8 -*-

#########################################
#                                       #
#       source code for InteGO2         #
#                                       #
#########################################

import os, math, sys, time
import getopt
from multiprocessing import Pool

from PyGOSim.Yu import *
from PyGOSim.Wang import *
from PyGOSim.Resnik import *
from PyGOSim.Schliker import *
from PyGOSim.simUI import *
from PyGOSim.simGIC import *
from PyGOSim.TO import *
from PyGOSim.RSS import *
from PyGOSim.HRSS import *

from PyGOSim.InteGO2 import ranksim
from PyGOSim.InteGO2 import merge
from PyGOSim.InteGO2 import cluster
from PyGOSim.InteGO2 import normlize as normlizer

#import query_mapping
#import email_sender


def run_basic_method(measure='resnik', single=False):

    print (paths)

    if single:
        result_path = run_path+'result_o.txt'
    else:
        result_path = run_path+'result_'+measure+'.txt'
    # return result_path

    if measure == 'yu':
        m = Yu(domain, species, paths)
    if measure == 'resnik':
        m = Resnik(domain, species, paths)
    elif measure == 'schliker':
        m = Schliker(domain, species, paths)
    elif measure == 'wang':
        m = Wang(domain, species, paths)
    elif measure == 'simUI':
        m = simUI(domain, species, paths)
    elif measure == 'simGIC':
        m = simGIC(domain, species, paths)
    elif measure == 'TO':
        m = TO(domain, species, paths)
    elif measure == 'RSS':
        m = RSS(domain, species, paths)
    elif measure == 'HRSS':
        m = HRSS(domain, species, paths)
    else:
        return

    result_file = open(result_path, 'w')
    count, total = 0, len(gene_pair_list)
    sim = {} #字典
    for pair in gene_pair_list.keys():
        # if not sim.has_key(pair):
        if not pair in sim.keys():
        # if g1 == g2: continue
        # pair = "_".join(sorted([g1, g2]))
            (g1, g2) = pair.split("_")
            count += 1
            sim[pair] = m.run(g1, g2)
            # print_progress(pair+'\t'+str(sim[pair]), count*100.0*2/total)
            result_file.write("%s\t%s\t%0.3f\n"%(g1, g2, float(sim[pair])))
            # result_file.flush()
    return result_path

def run_rank_sim(measure='resnik', result_path=''):
    ranksim.input_file = result_path
    os.system('sort -r -n -k 3 %s -o %s'%(result_path, run_path+'sort_tmp_'+measure))
    os.system('mv %s %s'%(run_path+'sort_tmp_'+measure, result_path))
    # #
    ranksim.output_file = run_path +'rank_'+measure+'.txt'
    ranksim.main()
    return ranksim.output_file

def run_merge(input_paths):
    merge.inputs = input_paths
    merge.output = run_path +'rank_all.txt'
    merge.main()
    return merge.output

def run_cluster(rankall_path):
    print (rankall_path)
    cluster.web = True
    cluster.input_f = rankall_path
    cluster.output_f = run_path +'result_o.txt'
    cluster.run()
    return cluster.output_f

def process_result(cluster_o_path, gene_list_path):
    result_path = run_path + 'result_oo.txt'
    gene_set = {}
    # for line in open(gene_list_path):
        # gene_set[line[:-1].strip()] = None
    result_w = open(result_path, 'w')
    for line in open(cluster_o_path):
        (g1, g2, sim) = line[:-1].split('\t')
        # if gene_set.has_key(g1) and gene_set.has_key(g2):
        # if mapped_ori_gene_pair_list.has_key('_'.join(sorted([g1, g2]))):
        if '_'.join(sorted([g1, g2])) in mapped_ori_gene_pair_list.keys():
            if need_map:
                result_w.write('\t'.join([reverse_map_list[g1],
                    reverse_map_list[g2], '%0.3f'%(float(sim))] )+'\n')
                # print '\t'.join([reverse_map_list[g1], reverse_map_list[g2], '%0.3f'%(float(sim))] )+'\n'
            else:
                result_w.write('\t'.join([g1, g2, '%0.3f'%(float(sim))] )+'\n')
    return result_path

def run_normlize(measure, input_file):
    normlizer.input_file = input_file
    normlizer.output_file = run_path + 'rank_' + measure + '.txt'
    normlizer.main()
    return normlizer.output_file

def async_task(m):
    print ('[Info]', 'Run task %s (%s)...' % (m, os.getpid()))
    start = time.time()
    result_path = run_basic_method(m)
    rank_tmp_file = run_rank_sim(m, result_path)
    # normlize for rank result
    run_normlize(m, rank_tmp_file)
    end = time.time()
    print ('[Info]', 'Task %s runs %0.2f seconds.' % (m, (end - start)))

def run_intego2(max_thread_num=2):
    rank_paths = []
    p = Pool(max_thread_num)
    print ('[Info]', "Starting...")
    for m in measures:
        print ('[Info]', m)
        p.apply_async(async_task, args=(m, ))
        # async_task(m)
        rank_path = run_path +'rank_'+m+'.txt'
        rank_paths.append(rank_path)
        # exit(1)
    print ('[Info]', "Waiting for all subprocesses done...")
    p.close()
    p.join()
    print ('[Info]', "All subprocesses done.")
    rankall_path = run_merge(rank_paths)
    cluster_o_path = run_cluster(rankall_path)
    # cluster_path = run_trim_bg_gene(cluster_o_path, run_path+'gene_list.txt')
    # print cluster_o_path


if __name__ == '__main__':

    opts, args = getopt.getopt(sys.argv[1:], "a:g:d:f:s:m:p:i:e:t:")

    run_id, domain, use_bg_set, species = '', 'BP', True, 9606

    need_map, map_from, map_to = False, '', ''

    measure, email, exp_name, result_link = 'wang', '', '', ''

    go_file, ann_file, all_gene_file, input_gene_file = '/home/yimiaofeng/PycharmProjects/SLBench/Intego2/data/go.obo', '/home/yimiaofeng/PycharmProjects/SLBench/Intego2/data/QuickGO_annotations_all.gaf', '/home/yimiaofeng/PycharmProjects/SLBench/Intego2/data/all_goa_symbol.txt', '/home/yimiaofeng/PycharmProjects/SLBench/Intego2/data/input_goa_symbol.txt'

    max_thread_num = 2

    data_path = "/Users/stark/Downloads/SLBench/Intego2/data/"
    run_path = '/home/yimiaofeng/PycharmProjects/SLBench/Intego2/simout/from_human_sl_wang_tmp'
    # run_path = data_path + 'run/'
    # print opts

    for op, value in opts:
    #    if op == "-r":
    #        run_id = value
        if op == '-a':
            ann_file = value
        elif op == '-g':
            go_file = value
        elif op == '-f':
            all_gene_file = value
        elif op == '-d':
            domain = value
        elif op == '-p':
            run_path = value
        elif op == '-s':
            species = value
        elif op == '-m':
            measure = value
        elif op == '-i':
            input_gene_file = value
        elif op == '-e':
            exp_name = value
        elif op == '-t':
            max_thread_num = int(value)

    # use_bg_set = False
    
    print ('[Info]', '-->run_path:', run_path)
    print ('[Info]', '---->need map', need_map)

    # write error msg to file , let user know
    #msg_fp = open(run_path + 'msg', 'w')
    log_fp = open(run_path + 'info.txt', 'w')
    log_fp.write('Basic info\n');
    log_fp.write('================================================\n');
    log_fp.write('Experiment Name: %s\n'%exp_name);
    log_fp.write('Taxon id: %s\n'%species);
    log_fp.write('GO category: %s\n'%domain);
    log_fp.write('Similarity measurement: %s\n'%measure);
    log_fp.write('\n\n');
    log_fp.write('Gene list Info\n');
    log_fp.write('================================================\n');

    measures = [
        "yu",
        "wang",
        "schliker",
        "resnik",
        "simGIC",
        "HRSS",
        "RSS",
        "TO",
        "simUI",
    ]

    paths = {
        'go_file'     : go_file,
        'ann_file'    : ann_file,
        'all_list_file' : all_gene_file,
        # 'gene_list_file' : data_path+'web/gene_list.txt',
    }

    file_format = 'list'

    file_name = input_gene_file
    
    all_annotated_gene_list = []
    for l in open(paths['all_list_file']):
        all_annotated_gene_list.append(l.strip())

    tmp_list = []
    for line in open(file_name):
        g = line.strip()
        if len(g) > 0:
            tmp_list.append(g)

    t = {}
    ori_gene_pair_list = {}
    if len(tmp_list[0].split(' ')) >= 2: # file format is PAIR
        file_format = 'pair'
        print ('[Info]', '--->file format is pair', tmp_list[0].split(' '))
        # translate PAIR into LIST
        for it in tmp_list:
            d = it.split(' ')
            # if len(d) != 2: continue
            g1, g2 = '', ''
            for i in range(len(d)):
                if len(d[i]) != 0:
                    g1 = d[i]
                    # print i, g1
                    break
            for i in range(len(d)-1, -1, -1):
                if len(d[i]) != 0:
                    g2 = d[i]
                    # print i, g2
                    break

            # print g1, g2
            if g1 == '' or g2 == '' or g1 == g2:
                # msg_fp.write('E'+'Input-format-wrong\n')
                print ("[Error] input gene file format is wrong")
                exit()
                
            t[g1], t[g2] = None, None
            ori_gene_pair_list['_'.join(sorted([g1,g2]))] = None
        tmp_list = t.keys()

    log_fp.write('The original gene num is %d\n'%(len(tmp_list)))
    if need_map:
        map_result = False
        for i in range(10):
            try:
                print ('[map] mapping...')
                map_result = query_mapping.tran(map_from, map_to, ' '.join(tmp_list))
                break # if map sucess, stop the loop
            except (Exception, e):
                print ('[map]', e, 'try again...')
                continue # try again
        if map_result == False:
            #msg_fp.write('E'+'Map-failed\n')
            exit()
        map_file = run_path + 'map.txt'
        map_fp = open(map_file, 'w')
        mapped_list = []
        reverse_map_list = {}
        map_list = {}
        for k in map_result.keys():
            reverse_map_list[map_result[k][-1]] = k
            map_list[k] = map_result[k][-1]
            mapped_list.append(map_result[k][-1])
            map_fp.write(k+'\t'+map_result[k][-1]+'\n')
        map_fp.close()

        #msg_fp.write('I'+'Map success, original gene num is %d, mapped gene num is %d\n'%(len(tmp_list), len(mapped_list)))
        log_fp.write('Mapped gene num is %d, %d genes is missing\n'%(len(mapped_list), len(tmp_list) - len(mapped_list)))

        if len(tmp_list) > len(mapped_list):
            log_fp.write('Genes that has not been mapped:\n')
            for g in tmp_list:
                if g not in reverse_map_list.values():
                    log_fp.write('\t%s\n'%g)
            log_fp.write('\n')

        print ('[Info]', 'original num:', len(tmp_list), 'mapped num:', len(mapped_list))

        all_gene_list = mapped_list
    else:
        all_gene_list = tmp_list

    before_len = len(all_gene_list)
    t_list, lost_gene_list = [], []
    for g in all_gene_list:
        if g in all_annotated_gene_list:
            t_list.append(g)
        else:
            lost_gene_list.append(g)
            print ('[Info]', 'lost gene:', g)

    log_fp.write('The number of gene that don\'t have annotation is %d\n'%len(lost_gene_list))
    if len(lost_gene_list) > 0:
        log_fp.write('Genes that don\'t have annotation:\n')
        for g in lost_gene_list:
            if need_map:
                log_fp.write('\t%s\n'%(reverse_map_list[g]))
            else:
                log_fp.write('\t%s\n'%(g))

        log_fp.write('\n')

    if need_map:
        log_fp.write('\n\n')
        log_fp.write('Gene ID map table (from %s to %s)\n' % (map_from, map_to))
        log_fp.write('================================================\n');
        for k in map_list.keys():
            log_fp.write('%s\t%s\n' % (k, map_list[k]))
        log_fp.close()

    all_gene_list = t_list
    print ('[Info]', 'The number of gene that has none annotation is %d'%(len(lost_gene_list)))
    if len(lost_gene_list) == before_len:
        print ("[Error] no annotated gene left")
        exit()

    # use to trim bg gene pair from result
    mapped_ori_gene_pair_list = {}
    if file_format == 'pair':
        for k in ori_gene_pair_list.keys():
            g1, g2 = k.split('_')
            if need_map:
                mapped_ori_gene_pair_list['_'.join(sorted([map_list[g1],map_list[g2]]))] = None
            else:
                mapped_ori_gene_pair_list['_'.join(sorted([g1 ,g2]))] = None
    else:
        for g1 in all_gene_list:
            for g2 in all_gene_list:
                mapped_ori_gene_pair_list['_'.join(sorted([g1 ,g2]))] = None

    # print mapped_ori_gene_pair_list

    # print all_gene_list
    print ('[Info]', '*'*30, len(all_gene_list))

    gene_pair_list = {}
    for g1 in all_gene_list:
        for g2 in all_gene_list:
            if g1 == g2: break
            gene_pair_list['_'.join(sorted([g1,g2]))] = None
    print ('[Info]', 'len of gene_pair_list:', len(gene_pair_list))

    if measure == 'InteGO2':
        run_intego2(max_thread_num)
    elif measure in measures:
        run_basic_method(measure, single=True)
    else:
        # error
        print ('[Error]', 'Unkonw measure')
        exit()

    result_o_path = run_path + 'result_o.txt'
    result_oo_path = run_path + 'result_oo.txt'
    result_path = run_path + 'result.txt'

    # only run normlize for `resnik` measure
    if measure == 'resnik':
        r_f_name = run_normlize('resnik', result_o_path)
        os.system('mv %s %s'%(r_f_name, result_o_path))

    result_oo_path = process_result(result_o_path, run_path+'gene_list.txt')

    if file_format == 'pair':
        # trim useless pair
        o_tmp_list = {}
        for line in open(file_name):
            d = line.strip().split(' ')
            if len(d) != 2:
                continue
            key = '-'.join(sorted(d))
            o_tmp_list[key] = None

        ww = open(result_path, 'w')
        # print o_tmp_list
        for line in open(result_oo_path):
            d = line.strip().split('\t')
            # if len(d) != 2: continue
            key = '-'.join(sorted([d[0], d[1]]))
            # print o_tmp_list[key]
            if key in o_tmp_list:
                ww.write(line)
        ww.close()
    else:
        os.system('cp %s %s'%(result_oo_path, result_path))
    
    # sort !!!
    os.system('sort -r -n -k 3 %s -o %s'%(result_path, run_path+'sort_tmp'))
    os.system('mv %s %s'%(run_path+'sort_tmp', result_path))
    # os.system('rm %s %s'%(result_o_path, result_oo_path));
    os.system('rm %s %s'%(run_path+'result_*.txt', run_path+'rank_*.txt'));

    # msg_fp.write('S'+'computer complete!\n')

    print ('[InteGO2]', 'Compute complete!')

