
How to use this package
=====

1. Install python package 'numpy'(https://pypi.python.org/pypi/numpy), 'scipy'(https://pypi.python.org/pypi/scipy) and 'networkx'(https://pypi.python.org/pypi/networkx/) in your computer. If you have installed python-pip tools(run command `apt-get install python-pip` in ubuntu), you can install package as below:
  * numpy: `pip install numpy`
  * scipy: `pip install scipy`
  * networkx: `pip install networkx`
2. Download gene ontology and annotation file from InteGO2 website(http://mlg.hit.edu.cn:8089/download).
3. Unzip InteGO2-release.zip file.
4. run `sample-run.sh` or run command `python intego2.py [args]`


Usage of intego2.py
=====

Run: `python intego2.py [args]`

* -g : Gene Onotology file path.
* -a : Annotation file path (downloaded from InteGO2 website).
* -f : All gene list file path (downloaded from InteGO2 website).
* -s : Taxon id (for example 9606 for Homo sapiens).
* -m : Gene similarity measure, available measures includes : InteGO2, resnik, wang, schliker, simGIC, simUI, RSS, HRSS, TO.
* -i : Input gene list file path.
* -p : A path that result file will be output.
* -t : Max worker thread number (Optional, multi-thread mode only available when measure is InteGO2).


Contact
=====

If you have any question or suggestion when using this package, you can send a email to 'jiajiep@gmail.com'.


