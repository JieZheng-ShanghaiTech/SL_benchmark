#-*- coding: UTF-8 -*-

import os
import math
import networkx as nx
from PyGOSim.Measure import *

'''
Schliker
'''
class Schliker(Measure, GeneSim):
    def __init__(self, domain, species, paths):
        Measure.__init__(self, domain, species, paths)

    def term_sim(self, t1, t2):
        lca = self.get_LCA(t1, t2)
        return 2*self.IC(lca)*(1-self.G(lca)/self.G_root)/\
                 (self.IC(t1) + self.IC(t2))

