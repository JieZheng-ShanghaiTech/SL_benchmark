#-*- coding: UTF-8 -*-

import os


'''
Fields in the annotation file
Column   Content                Required?   Cardinality     Example
1        *DB                     required    1               UniProtKB
2        *DB Object ID           required    1               P12345
3         DB Object Symbol       required    1               PHO3(yeast)
4         Qualifier              optional    0 or greater    NOT
5        *GO ID                  required    1               GO:0003993
6         DB:Reference           required    1 or greater    PMID:2676709
7        *Evidence Code          required    1               IMP
8         With(or)From           optional    0 or greater    GO:0000346
9        *Aspect                 required    1               F
10        DB Object Name         optional    0 or 1          Toll-like receptor 4 (TAIR)
11        DB Object Synonym      optional    0 or greater    hToll|Tollbooth
12        DB Object Type         required    1               protein
13       *Taxon(|taxon)          required    1 or 2          taxon:9606
14        Date                   required    1               20090118
15        Assigned By            required    1               SGD
16        Annotation Extension   optional    0 or greater    part_of(CL:0000576)
17        Gene Product Form ID   optional    0 or 1          UniProtKB:P12345-2
'''

class Ann():
    def __init__(self, line, g_index=1):
        d = line[:-1].split('\t')
        self.DB = d[0]
        self.Gene = d[g_index]
        self.Term = d[4]
        self.Evidence = d[6]
        self.Aspect = d[8]
        self.Taxon = d[12].split('|')[0]
    def __str__(self):
        return 'Annotation:'+ '\n\tgenes\t' + str(self.Gene) + '\n\tterms\t' + str(self.Term)

class AnnIter():
    def __init__(self, domain, path, species):
        self.path = path
        self.domain = domain[-1] # F/C/P
        self.species = species
        self.taxon = species
        if species == '3702':
            self.g_index = 9
        else:
            self.g_index = 1
    def __iter__(self):
        return self.next()
    def next(self):
        with open(self.path) as f:
            for line in f:
                # 32489974
                if line[0] == '!':continue
                ann = Ann(line, self.g_index)
                if ann.Aspect != self.domain:
                    continue
                yield ann

class Annotation():
    def __init__(self, domain, path, species='all', GO=None):
        all_ann = AnnIter(domain, path, species)
        GO_term = {}
        for t in GO:
            GO_term[t] = None
        
        self.gene = {} # gene:{terms}
        self.term = {} # term:{genes}
        for ann in all_ann:
            # print ann
            if GO is not None and not ann.Term in GO_term:
                # print ann.Term, 'not in GO'
                continue
            if ann.Gene in self.gene: # genes
                self.gene[ann.Gene].append(ann.Term)
            else:
                self.gene[ann.Gene] = [ann.Term, ]

            if ann.Term in self.term: # terms
                self.term[ann.Term].append(ann.Gene)
            else:
                self.term[ann.Term] = [ann.Gene, ]
        print ('tota genes num:', len(self.gene))
        print ('tota terms num:', len(self.term))

    def __str__(self):
        return 'Annotation:'+ '\n\tgenes ' + str(self.gene) + '\n\tterms' + str(self.term)

    def get_terms_by_gene(self, gene):
        if gene in self.gene:
            return set(self.gene[gene])
        else:
            return set()

    def get_genes_by_term(self, term):
        if term in self.term:
            return set(self.term[term])
        else:
            return set()

    def get_all_genes_by_terms(self, all_term):
        genes = {}
        for t in all_term:
            for g in self.get_genes_by_term(t):
                if g not in genes:
                    genes[g] = None
        return genes.keys()

    def get_all_gene_list(self):
        return self.gene.keys()


