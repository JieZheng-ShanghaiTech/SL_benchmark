#-*- coding: UTF-8 -*-

import os
import math
import networkx as nx

from PyGOSim.Measure import *

'''
Measure HRSS
hybrid edge-based & IC-based
'''
class HRSS(Measure, GeneSim):
    def __init__(self, domain, species, paths):
        Measure.__init__(self, domain, species, paths)
        self.beta_cache = {}
        # print 'preprocessing...'

    def get_beta(self, source):
        if source in self.beta_cache.keys():
        # if self.beta_cache.has_key(source):
            return self.beta_cache[source]
        cur_max, source_ic = self.IC(source), self.IC(source)
        t = source
        sub = self.GO.subgraph(nx.algorithms.dag.descendants(self.GO, source) | set([source]))
        for (node, degree) in sub.out_degree_iter():
            if degree == 0: # only consider leaf node
                try:
                    l = self.IC(node)
                except ValueError('no gene annotated , skip term'):
                    # no gene annotated , skip term
                    continue
                if l > cur_max:
                    cur_max = l
                    t = node
        r = cur_max - source_ic
        if r < 0:
            raise ValueError('source: '+source+' node: '+t+' '+str(cur_max)+' - '+str(source_ic))
        self.beta_cache[source] = r
        return r

    def dist_ic(self, u, v):
        return self.IC(v) - self.IC(u)

    def term_sim(self, t1, t2):
        # print t1, t2, ':', 
        MRCA = self.get_MRCA(t1, t2)
        alpha = self.dist_ic(self.root, MRCA)
        beta =  ( self.get_beta(t1) + self.get_beta(t2) )/2.0
        gamma = self.dist_ic(MRCA, t1) + self.dist_ic(MRCA, t2)
        # print "mrca", MRCA, 
        # print alpha, beta, gamma,

        if alpha == 0: return 0.0
        else: p2 = (float(alpha)/(alpha+beta))

        term_sim = (1.0/(1.0+gamma)) * p2
        # print term_sim
        return term_sim

