#-*- coding: UTF-8 -*-

import os
import math
import networkx as nx

from PyGOSim.Measure import *

'''
Measure RSS
edge-based
'''
class RSS(Measure, GeneSim):
    def __init__(self, domain, species, paths):
        Measure.__init__(self, domain, species, paths)
        print ('preprocessing...')
        self.max_depth = 0
        pred, dist = nx.bellman_ford(self.GO, self.root, weight="w")
        print (len(dist))
        for (node, degree) in self.GO.out_degree_iter():
            if degree == 0: # only consider leaf node
                # get LONGEST path length, because of every edge's weight = -1
                if self.GO.in_degree(node) == 0: continue
                if dist[node] < self.max_depth:
                    self.max_depth = dist[node]
        self.max_depth = -self.max_depth
        self.beta_cache = {}
        # print self.max_depth

    def get_beta(self, source):
        if source in self.beta_cache.keys():
        # if self.beta_cache.has_key(source):
            return self.beta_cache[source]
        cur_min = self.max_depth
        sub = self.GO.subgraph(nx.algorithms.dag.descendants(self.GO, source) | set([source]))
        # print nx.algorithms.dag.descendants(self.GO, source)| set([source])
        # print sub.edges()
        for (node, degree) in sub.out_degree_iter():
            if degree == 0: # only consider leaf node
                # print '->', source, node
                l = nx.shortest_path_length(sub, source=source, target=node)
                if l < cur_min:
                    cur_min = l
        self.beta_cache[source] = cur_min
        return cur_min

    def dist(self, s, t):
        return nx.shortest_path_length(self.GO, source=s, target=t)


    def term_sim(self, t1, t2):
        # print t1, t2, ':', 
        alpha, beta, gamma = 0.0, 0.0, 0.0
        MRCA = self.get_MRCA(t1, t2)
        alpha = self.dist(self.root, MRCA)
        beta =  ( self.get_beta(t1) + self.get_beta(t2) )/2.0
        gamma = self.dist(MRCA, t1) + self.dist(MRCA, t2)
        # print "mrca", MRCA, 
        # print alpha, beta, gamma

        if alpha == 0: return 0.0
        else: p2 = (float(alpha)/(alpha+beta))

        return (float(self.max_depth)/(self.max_depth+gamma)) * p2

