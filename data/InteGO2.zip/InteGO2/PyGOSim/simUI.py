#-*- coding: UTF-8 -*-

import os
import math
import networkx as nx

from PyGOSim.Measure import *

'''
Measure simUI
'''
class simUI(Measure, GeneSim):
    def __init__(self, domain, species, paths):
        Measure.__init__(self, domain, species, paths)

    def run(self, g1, g2):
        g1_t = self.ann.get_terms_by_gene(g1)
        g2_t = self.ann.get_terms_by_gene(g2)
        intersection = g1_t & g2_t
        union = g1_t | g2_t


        downer = float(len(union))
        if downer == 0:
            #print (g1, g2)
            return 0
        # print intersection, union, len(intersection) / downer
        return len(intersection) / downer

