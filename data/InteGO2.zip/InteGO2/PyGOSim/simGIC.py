#-*- coding: UTF-8 -*-

import os
import math
import networkx as nx

from PyGOSim.Measure import *

'''
Measure simGIC
'''
class simGIC(Measure, GeneSim):
    def __init__(self, domain, species, paths):
        Measure.__init__(self, domain, species, paths)

    def sum_IC(self, ts):
        sum = 0.0
        for t in ts:
            sum += self.IC_uniform(t)
        return sum

    def run(self, g1, g2):
        g1_t = self.ann.get_terms_by_gene(g1)
        g2_t = self.ann.get_terms_by_gene(g2)
        intersection = g1_t & g2_t
        union = g1_t | g2_t
        # print intersection, union
        downer = float(self.sum_IC(union))
        if downer == 0:
            print (g1, g2)
            return 0
        sim = self.sum_IC(intersection) / downer
        # print intersection, union, sim
        return sim

