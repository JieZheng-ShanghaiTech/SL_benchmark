#-*- coding: UTF-8 -*-

import os
from xml.dom import minidom

class Term:
    def __init__(self):
        self.id = None
        self.name = ""
        self.namespace = ""
        self.relation = []
    def __str__(self):
        return str(self.id) + ":" + str(self.name)+ '\t' + str(self.relation)
        #, self.name, self.namespace, self.relation)


class GOParser():
    def __init__(self, path):
        self.file = open(path)
        self.end = False
        while True: # skip header
            if self.file.readline()[0] == '[': # first term
                break

    def __iter__(self):
        return self

    def __next__(self):
        if self.end :
            raise StopIteration
        t = Term()
        while True:
            line = self.file.readline()
            if len(line) == 0:
                self.end = True
                return t
            elif line.startswith('id:'):
                t.id = line[len('id:'):].strip()
            elif line.startswith('name:'):
                t.name = line[len('name:'):].strip()
            elif line.startswith('namespace:'):
                t.namespace = line[len('namespace:'):].strip()
            elif line.startswith('is_a:'):
                t.relation.append({'type':'is_a', 'parent':line[len('is_a:'):line.index('!')].strip()})
            elif line.startswith('relationship:'):
                line = line[len('relationship:'):].strip()
                if line.startswith('part_of'):
                    t.relation.append({'type':'part_of', 'parent':line[len('part_of:'):line.index('!')].strip()})
            elif line.startswith('[Term]'): # reach next term
                return t
            else:
                continue
        return t # at end of file, the last term
    
    def next(self):
        return self.__next__()

class GOParser_XML():
    def __init__(self, path):
        self.doc = minidom.parse(path)
        self.terms = self.doc.getElementsByTagName('term')
        print ('load done.', len(self.terms))

    def __iter__(self):
        return self.next()

    def getTagText(self, node):
        rc = ""
        for node in node.childNodes:
            if node.nodeType in ( node.TEXT_NODE, node.CDATA_SECTION_NODE):
                rc = rc + node.data
            return rc

    def next(self):
        for term in self.terms:
            t = Term()
            t.id = self.getTagText(term.getElementsByTagName('id')[0])
            t.name = self.getTagText(term.getElementsByTagName('name')[0])
            t.namespace = self.getTagText(term.getElementsByTagName('namespace')[0])
            for r in ['is_a', 'part_of']:
                for node in term.getElementsByTagName(r):
                    t.relation.append({'type':r, 'parent':self.getTagText(node)})
            # return t
            yield t




