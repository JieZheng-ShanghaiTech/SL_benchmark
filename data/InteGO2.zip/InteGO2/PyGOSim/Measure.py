#-*- coding: UTF-8 -*- 
import os
import math
# import cPickle
import networkx as nx

import PyGOSim.toDAG
import PyGOSim.Annotation

'''
common methods
'''
class Measure:

    def __init__(self, domain, species, paths):
        #gml_path = "/home/lhx/workspace/GO/data/go_gml/"
        self.domain = domain
        self._get_path(paths)
        print ('parsing GO file...')
        self.GO = PyGOSim.toDAG.parse_to_G(self.file_path)
        # print self.
        self.GO = self.GO[domain]

        print ('loading annotation...')
        self.ann = PyGOSim.Annotation.Annotation(domain, self.ann_path, species, self.GO.nodes())
        print ("load done!!!")
        self.root = self.GO.graph['root'] # 根节点
        print (self.root)
        self.ic_cache, self.G_cache = {self.root:0.00001}, {}
        print ('calculating G_root...')
        self.G_root = self.G(self.root)
        print ('G_root is', self.G_root)
        # self.G_root = 36980.0
        self.log_G_root =  math.log(self.G_root) # for caculate uniform ic
    '''
    get paths
    '''
    def _get_path(self, paths):
        try:
            self.file_path = paths['go_file']
            self.ann_path  = paths['ann_file']
        except (KeyError) as e:
            print (e)
            os._exit(-1)

    '''
    the number of genes annotated to term t
    '''
    def G(self, t):
        if t not in self.G_cache:
            self.G_cache[t] = float(len(self.G_set(t)))
        return self.G_cache[t]

    '''
    the set of genes annotated to term t
    '''
    def G_set(self, t):
        all_t = nx.descendants(self.GO, t)
        all_t = all_t.union([t])
        return self.ann.get_all_genes_by_terms(all_t)

    '''
    Information Content for term t
    '''
    def IC(self, t):
        if t not in self.ic_cache:
            G_t = self.G(t)
            # print G_t
            if G_t > self.G_root:
                raise ValueError('how can!!')
            if G_t == 0:
                raise ValueError(f"ERROR:{t} has no gene annotated")
            self.ic_cache[t] = -math.log(float(G_t)/self.G_root) # ln()
        return self.ic_cache[t]

    '''
    Uniform Information Content for term t
    '''
    def IC_uniform(self, t):
        if self.IC(t) > self.log_G_root:
            print (t, self.IC(t), self.log_G_root, self.IC(t) / self.log_G_root)
        return self.IC(t) / self.log_G_root

    '''
    取公共子图中出度为0的node作为候选
    找到IC最大的node返回
    '''
    def get_LCA(self, t1, t2):
        a1 = nx.algorithms.dag.ancestors(self.GO, t1)
        a2 = nx.algorithms.dag.ancestors(self.GO, t2)
        common_a = a1 & a2 # 公共的祖先 
        sub = self.GO.subgraph(common_a)
        cur_max_ic, cur_lca = -1, self.root
        for (node, degree) in sub.out_degree_iter():
            if degree == 0:
                # ic = self.IC_uniform(node)
                ic = self.IC(node)
                if ic > cur_max_ic:
                    cur_lca, cur_max_ic = node, ic
        return cur_lca

    '''
    Most Recent Common Ancestor
    find the longest path of all shortest path from root to CA
    '''
    def get_MRCA(self, t1, t2):
        a1 = nx.algorithms.dag.ancestors(self.GO, t1)
        a2 = nx.algorithms.dag.ancestors(self.GO, t2)
        common_a = a1 & a2 # 公共的祖先 
        sub = self.GO.subgraph(common_a)
        cur_longest, cur_lca = -1, self.root
        for (node, degree) in sub.out_degree_iter():
            if degree == 0:
                l = nx.shortest_path_length(sub, source=self.root, target=node)
                if l > cur_longest:
                    cur_lca, cur_longest  = node, l
        return cur_lca


'''
通过term-term计算gene-gene相似度
'''
class GeneSim:
    def __init__(self):
        pass
    def upper_sum(self, l):
        s = []
        for k in l.keys():
            s.append(max(l[k]))
        return s

    def run_term(self, path=None):
        if path is None:
            print ("no path, exit")
            return
        f = open(path, 'w')
        terms = self.ann.term.keys()
        print ('term count ', len(terms))
        count = 0
        for t1 in terms:
            count += 1
            print (str(count * 100 / len(terms))+'%')
            for t2 in terms:
                if t1 == t2: break
                term_sim = float(self.term_sim(t1, t2))
                f.write(t1+'\t'+t2+'\t'+str(term_sim)+'\n')

    def run(self, g1, g2):
        g1_t = self.ann.get_terms_by_gene(g1)
        g2_t = self.ann.get_terms_by_gene(g2)
        g1_d, g2_d = {}, {}
        data = {}
        for t1 in g1_t:
            for t2 in g2_t:
                # if t1 == t2: continue
                # print t1, t2, '->', 
                key = '_'.join(sorted([t1, t2]))
                if key not in data:
                    data[key] = float(self.term_sim(t1, t2))

                term_sim = data[key]

                if t1 in g1_d: g1_d[t1].append(term_sim)
                else: g1_d[t1] = [term_sim]
                if t2 in g2_d: g2_d[t2].append(term_sim)
                else: g2_d[t2] = [term_sim]

                # print data[key]

        return self.best_match_wang(g1_d, g2_d)
        # return self.best_match(g1_t, g2_t, data)

    def max(self, g1_d, g2_d, data):
        return 0

    def best_match(self, g1_t, g2_t, data):
        upper, d = 0.0, [g1_t, g2_t]
        for i in [0, 1]:
            ssum = 0.0
            for t1 in d[i]:
                cur_max = -1
                for t2 in d[(i+1)%2]:
                    key = '_'.join(sorted([t1, t2]))
                    if data[key] > cur_max:
                        cur_max = data[key]
                    # if cur_max > 0.7:
                        # print cur_max
                ssum += cur_max

            upper += float(ssum)/len(d[i]) # average
            # if upper > 1.0:
            #     print '--->', upper
        return float(upper) / 2.0

    def best_match_wang(self, g1_d, g2_d):
        l_1, l_2 = self.upper_sum(g1_d), self.upper_sum(g2_d)
        upper = sum(l_1) + sum(l_2)
        downer = len([e for e in l_1 if e != 0])\
               + len([e for e in l_2 if e != 0])
        if downer == 0.0:
            return 0
        else:
            return float(upper) / downer

