#-*- coding: UTF-8 -*-

import os
import math
import networkx as nx
from PyGOSim.Measure import *



'''
Measure Wang
'''
class Wang(Measure, GeneSim):
    # semantic contribution factor
    w = {
        'is_a' : 0.8,
        'part_of' : 0.6,
    }
    def __init__(self, domain, species, paths):
        Measure.__init__(self, domain, species, paths)
        self.S_cache = {}
    def S(self, t):
        if t in self.S_cache:
            return self.S_cache[t]
        r = {t:1.0} # init
        a = nx.algorithms.dag.ancestors(self.GO, t)
        topo = nx.algorithms.dag.topological_sort(self.GO.subgraph(a).reverse()) # 计算顺序
        list(topo).insert(0, t)
        for node in topo:
            if node not in r:
                r[node] = max([self.w[self.GO[node][child]['type']]*r[child] for child in self.GO[node] if child in topo])
        self.S_cache[t] = r
        return self.S_cache[t]

    def term_sim(self, t1, t2):
        S1, S2 = self.S(t1), self.S(t2)
        upper = sum([(S1[t]+S2[t]) for t in set(S1.keys()) & set(S2.keys())])
        downer = sum(S1.values()) + sum(S2.values())
        return float(upper)/downer

