#-*- coding: UTF-8 -*-

import os
import math
import networkx as nx
from PyGOSim.Measure import *


'''
measure Resnik
'''
class Resnik(Measure, GeneSim):
    def __init__(self, domain, species, paths):
        Measure.__init__(self, domain, species, paths)
        print (self.G_root)
        self.cache = {}

    def term_sim(self, t1, t2):
        lca = self.get_LCA(t1, t2)
        # print '('+lca+')',
        if lca in self.cache.keys(): return self.cache[lca]
        # if self.cache.has_key(lca): return self.cache[lca]
        else: self.cache[lca] = self.IC(lca)
        # else: self.cache[lca] = self.IC_uniform(lca) # use UNIFORM IC
        return self.cache[lca]

