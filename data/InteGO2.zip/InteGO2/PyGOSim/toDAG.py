#-*- coding: UTF-8 -*-

import os
import networkx as nx
from PyGOSim.GOParser import GOParser, GOParser_XML, Term
# import PyGOSim.GOParser

G = {
    'BP': nx.DiGraph(name='BP', root='GO:0008150'),
    # 'MF': nx.DiGraph(name='MF', root='GO:0'),
    'MF': nx.DiGraph(name='MF', root='GO:0003674'),
    'CC': nx.DiGraph(name='CC', root='GO:0005575'),
}

short = {
    'biological_process': "BP",
    'molecular_function': "MF",
    'cellular_component': "CC",
}

def parse_to_G(file_path):
    term_list = []
    file_type = file_path[-3:]
    if file_type == "obo":
        GO = GOParser(file_path)
    elif file_type == "xml":
        GO = GOParser_XML(file_path)

    for t in GO:
        term_list.append(t)

    for t in term_list: # add nome to graph
        # print 'term', t
        if t.namespace in short:
            G[short[t.namespace]].add_node(t.id, name=t.name, namespace=short[t.namespace])

    for t in term_list:
        if t.namespace in short:
            for rel in t.relation:
                # set w=-1 for get the longest path
                G[short[t.namespace]].add_edge(rel['parent'], t.id, type=rel['type'], w=-1)

    # remove the relation cross two namespace ，eg: GO:0045121
    for name, g in G.items():
        for (u, v) in g.edges():
            if 'namespace' in g.node[u] and 'namespace' in g.node[v]:
                if g.node[u]['namespace'] == g.node[v]['namespace']:
                    continue 
            G[name].remove_edge(u, v)

    return G

def save_gml(G, gml_path):
    for name, g in G.iteritems():
        nx.write_gml(g, gml_path+g.graph['name']+'.gml')

# parse_to_gml()
def load_gml(file_path):
    G = nx.read_gml(file_path, relabel=True)
    return G
    

