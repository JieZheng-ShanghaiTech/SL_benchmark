#-*- coding: UTF-8 -*-

import os
import math
#import cPickle
import pickle
import networkx as nx

from PyGOSim.Measure import *

'''
Measure Yu
'''
class Yu(Measure, GeneSim):
    def __init__(self, domain, paths):
        Measure.__init__(self, domain, paths)
        print ('preprocessing...')
        self.lca_cache = {}
        self.g_cache = {}
        self.preprocess()
        print ('total N', self.N)
        # self.cache = {}

    def yu(self, n):
        return - math.log(float(n)/self.N) # ln()

    def C_n_2(self, n):
        return n * (n - 1) / 2

    '''
    get all about the number of gene pairs that have the SAME set of LCAs
    '''
    def preprocess(self):
        preprocess_file = '/home/lhx/workspace/GO/data/preprocess_yu_'+self.domain+'.txt'
        if os.path.exists(preprocess_file) == True:
            print ('fetching form file...')
            data = pickle.load(open(preprocess_file))
            # print data
            self.all_lca = data['lca']
            self.N = data['N']
            return
        f = open(preprocess_file, 'w')
        self.gene_list = self.ann.get_all_gene_list()
        self.N = self.C_n_2(len(self.gene_list))
        print ('NNN', self.N)
        self.all_lca = {}
        c = 0
        total = len(self.gene_list)
        print (total)
        for g1 in self.gene_list:
            c += 1
            print (g1, 'done', str(int(c*100.0/total))+'%', len(self.all_lca), len(self.g_cache)) # , len(self.lca_cache)
            for g2 in self.gene_list:
                if g1 == g2: break
                lca_key = self.get_lca_key(g1, g2)
                if not self.all_lca.has_key(lca_key):
                    self.all_lca[lca_key] = 0
                self.all_lca[lca_key] += 1

        data = {
            'lca' : self.all_lca,
            'N'   : self.N,
        }
        pickle.dump(data, f, -1)

    '''
    get the set of LCA for g1 and g2
    '''
    def get_lca_key(self, g1, g2):
        if not self.g_cache.has_key(g1):
            self.g_cache[g1] = self.ann.get_terms_by_gene(g1)
        if not self.g_cache.has_key(g2):
            self.g_cache[g2] = self.ann.get_terms_by_gene(g2)
        g1_t = self.g_cache[g1]
        g2_t = self.g_cache[g2]

        lcas = set()
        for t1 in g1_t:
            for t2 in g2_t:
                key = '_'.join(sorted([t1, t2]))
                # if not self.lca_cache.has_key(key):
                    # self.lca_cache[key] = self.get_LCA(t1, t2)
                # lcas.add(self.lca_cache[key])
                lcas.add(self.get_LCA(t1, t2))
        return "_".join(sorted(lcas))


    def run(self, g1, g2):
        lca_set = self.get_lca_key(g1, g2)
        return self.yu(self.all_lca[lca_set])

