#-*- coding: UTF-8 -*-
import sys
import getopt


def main():

    lines = open(input_file).readlines()
    new = open(output_file, 'w')

    total = len(lines)
    print ('[normlize]', 'total lines', total)
    data = {}

    for line in lines:
        # (pair, sim) = line[:-1].split('\t')
        (p1, p2, sim) = line[:-1].split('\t')
        data[p1+'_'+p2] = float(sim)

    d_max, d_min = max(data.values()), min(data.values())

    print ('[normlize]', d_max, d_min)
    downer = d_max - d_min

    if downer == 0:
        for pair in data.keys():
            new.write('\t'.join(pair.split('_'))+'\t'+str(data[pair])+'\n')
    else:
        for pair in data.keys():
            new.write('\t'.join(pair.split('_'))+'\t'+str((data[pair]-d_min)/downer)+'\n')


if __name__ == '__main__':
    
    opts, args = getopt.getopt(sys.argv[1:], "i:o:")
    input_file, output_file = '', ''

    for op, value in opts:
        if op == "-i":
            input_file = value
        elif op == "-o":
            output_file = value

    main()
# get_rank_sim(input_file, output_file)

