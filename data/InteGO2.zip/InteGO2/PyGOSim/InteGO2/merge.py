#-*- coding: UTF-8 -*-
import sys, os
import getopt

def main():
    data = {}
    print ('reading...')
    for (k, p) in enumerate(inputs[:-1]):
        data[k] = {}
        for l in open(p):
            d = l[:-1].split("\t")
            # if len(d) < 3: continue
            pair = '_'.join(sorted(d[0:2]))
            data[k][pair] = d[-1]

    w = open(output, 'w')
    print ('merging...')
    for l in open(inputs[-1]):
        # print l
        d = l[:-1].split("\t")
        # if len(d) < 3: continue
        pair = '_'.join(sorted(d[0:2]))
        line_list = pair.split("_") # pair
        for (k, p) in enumerate(inputs[:-1]):
            line_list.append(data[k][pair])

        line_list.append(d[-1]) # the last simlirty
        w.write("\t".join(line_list)+"\n")


def main2():
    for (k, p) in enumerate(inputs):
        if k > 0:
            r = open(output+'_tmp', 'r')
        w = open(output, 'w')
        print ('[merge]', k, p)
        # sort !!!
        os.system('sort -k 1 -k 2 %s -o %s'%(p, tmp_file))
        os.system('mv %s %s'%(tmp_file, p))
        for l in open(p):
            if k == 0: # write pair and sim
                w.write(l)
            else: # append sim value
                d = l[:-1].split('\t')
                ll = r.readline()
                w.write(ll[:-1]+'\t'+d[2]+'\n')
        if k > 0:
            r.close()
        w.close()

        if k < len(inputs) - 1: # if not the last file 
            os.system('mv %s %s'%(output, output+'_tmp'))
        print ('[merge]', p, 'done!')


if __name__ == '__main__':
    # 前k个参数是带merge的k个文件的路径，最后一个参数是输出文件路径
    opts, args = getopt.getopt(sys.argv[-2:], "o:")
    output = ''

    for op, value in opts:
        if op == "-o":
            output = value
    inputs = sys.argv[1:-2]

    main()

