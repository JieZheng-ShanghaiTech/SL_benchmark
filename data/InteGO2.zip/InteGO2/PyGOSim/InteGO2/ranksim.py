#-*- coding: UTF-8 -*-
import sys
import getopt

data_path = '/home/lhx/tmp/'


# print output_file
def main():
    lines = open(input_file).readlines()
    new = open(output_file, 'w')

    total = len(lines)
    print ('[ranksim]', 'total lines', total)
    pre_sim = '-1'
    count, rank = 0, 0
    for line in lines:
        # (pair, sim) = line[:-1].split('\t')
        (p1, p2, sim) = line[:-1].split('\t')
        if sim != pre_sim:
            pre_sim = sim
            rank  = count + 1
        # print count, rank, total, float(rank)/total
        count += 1
        rank_sim = 1 - float(rank)/total
        # rank_sim = float(rank)/total
        # new.write(pair+'\t'+str(rank_sim)+'\n')
        new.write(p1+'\t'+p2+'\t'+str(rank_sim)+'\n')

if __name__ == '__main__':
    opts, args = getopt.getopt(sys.argv[1:], "i:o:")
    input_file, output_file = '', ''

    for op, value in opts:
        if op == "-i":
            input_file = value
        elif op == "-o":
            output_file = value

    main()

