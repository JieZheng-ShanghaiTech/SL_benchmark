#-*- coding: UTF-8 -*-
import sys
import getopt
import random
import time
# import matplotlib.pyplot as plt
import numpy as np

from scipy.cluster.hierarchy import dendrogram, linkage
from numpy import array

# from matplotlib.backends.backend_pdf import PdfPages
# pp = PdfPages('multipage.'+str(int(time.time()))+'.pdf')

#################################################3
gene_ec = {}


def init_gene_ec(path):
    for line in open(path):
        d = line[:-1].split("\t")
        if len(d) < 2: continue
        (ec_num, gene) = d
        if not gene_ec.has_key(gene):
            gene_ec[gene] = []
        gene_ec[gene].append(ec_num)


def ec_value(a, b):
    # return 0
    if len(list(set(gene_ec[a]) & set(gene_ec[b]))) > 0:
        return 1
    else:
        return 0

all_m = [ "wang" , "sch" , "res" , "GIC" , "HRSS" , "RSS", "yu" , "TO"]

def plot_g(pair, sim, ec_v):
    label = []
    for (i, m) in enumerate(all_m):
        label.append(m+'('+str(round(sim[i], 2))+')')
    # print sim
    # print label
    plt.figure()
    plt.title(' '.join(pair)+" "+ec_v)
    dendrogram(linkage_matrix,
                color_threshold=1,
                truncate_mode='lastp',
                labels=label,
                distance_sort='ascending')
    plt.show()
    # pp.savefig()
    plt.close()

def get_cluster_by_num(clusternum = 3):
    clustdict = {i:[i] for i in xrange(len(linkage_matrix)+1)}
    for i in xrange(len(linkage_matrix)-clusternum+1):
        clust1= int(linkage_matrix[i][0])
        clust2= int(linkage_matrix[i][1])
        clustdict[max(clustdict)+1] = clustdict[clust1] + clustdict[clust2]
        del clustdict[clust1], clustdict[clust2]

    clusters = clustdict.values()
    if False:
        for c in clusters:
            for m in c:
                print (all_m[m],)
            print ("\n")
    return clusters

def get_cluster_auto():
    tmp_sim = [s for s in sim]
    tmp_sim.remove(max(sim))
    tmp_sim.remove(min(sim))
    threshold = sum(tmp_sim)/(10*len(tmp_sim))
    # print sim,  threshold
    clustdict = {i:[i] for i in xrange(len(linkage_matrix)+1)}
    for i in xrange(len(linkage_matrix)):
        if float(linkage_matrix[i][2]) >= threshold:
            break
        clust1= int(linkage_matrix[i][0])
        clust2= int(linkage_matrix[i][1])
        clustdict[max(clustdict)+1] = clustdict[clust1] + clustdict[clust2]
        del clustdict[clust1], clustdict[clust2]

    clusters = clustdict.values()
    if False:
        for c in clusters:
            for m in c:
                print (all_m[m],)
            print ("\n")
    return clusters

def get_cluster_by_threshold(threshold = 0.1):
    clustdict = {i:[i] for i in xrange(len(linkage_matrix)+1)}
    for i in xrange(len(linkage_matrix)):
        if float(linkage_matrix[i][2]) >= threshold:
            break
        clust1= int(linkage_matrix[i][0])
        clust2= int(linkage_matrix[i][1])
        clustdict[max(clustdict)+1] = clustdict[clust1] + clustdict[clust2]
        del clustdict[clust1], clustdict[clust2]

    clusters = clustdict.values()
    if False:
        for c in clusters:
            for m in c:
                print (all_m[m],)
            print ("\n")
    return clusters

# 选择类中方法较多的类取平均值
def get_new_sim(clusters):
    max_len = max([len(c) for c in clusters])

    candidate = []
    for c in clusters:
        if len(c) == max_len:
            for s in c:
                candidate.append(sim[s])
    new_sim = sum(candidate)/len(candidate)
    return new_sim

# 选择类中方法较多的类取平均值，如果有多个候选的类，选择类内距离最小的类
def get_new_sim2(clusters):
    max_len = max([len(c) for c in clusters])
    cur_min_d = 2.0
    for c in clusters:
        if len(c) == max_len:
            dd = [sim[x] for x in c]
            if cur_min_d > get_average_distance(dd):
                new_sim = sum(dd)/len(dd)
    return new_sim

#
#                  |
#                  |
#    ---   -----------------
#     |    |               |
#     |    |               |
#     s1   |               |
#     |    |               |
#     |    |               |
#    ---   |            --------
#          |            |      |
# ----s2---|------------|------|----
#          |            |      |
#      --------         |      |
#      |      |         |      |
#      |      |         |      |
#

threshold = {
    # for two big cluster
    's1':0.35, 
    's1_intra_distance':0.05,

    's2':0.13,

}

statistics = {
    's1':{
        'max':[0, 0],
        'min':[0, 0],
        'avg':[0, 0],
        },
    's2':{
        'max':[0, 0, 0],
        'min':[0, 0, 0],
        'avg':[0, 0, 0],
        },
}

ml = True

def avg(l):
    return sum(l)/float(len(l))

def mixture(w, m):
    return sum([w[i]*m[i] for i in range(len(w))])

# 复杂但灵活的方式
def get_new_sim3():

    basic_method, new_list = len(sim) - 1, range(len(sim))
    del_info = {'max':0, 'min':0, 'other':0}
    # step 2: deeper and deeper
    for i in sorted(range(1, len(linkage_matrix)), reverse=True):
        if linkage_matrix[i][2] < threshold['s2']:
            break
        for j in (0, 1):
            index = int(linkage_matrix[i][j])
            if index <= basic_method:
                new_sim_list = [sim[s] for s in new_list]
                if sim[index] == max(new_sim_list): del_info['max'] += 1
                elif sim[index] == min(new_sim_list): del_info['min'] += 1
                else: del_info['other'] += 1
                # print 'del', str(sim_list[index])
                new_list.remove(index)

    clusters = get_cluster_by_threshold(threshold['s2'])
    # print clusters
    m_groups, cur_max = [], 0
    min_size_of_group = 3
    for c in [cc for cc in clusters if len(cc) >= min_size_of_group]:
        if len(c) < cur_max:
            continue
        elif len(c) > cur_max:
            cur_max = len(c)
            m_groups[:] = []
        m_groups.append(c)
    # print m_groups
    # print '---------------'
    if len(m_groups) == 0: # no majority group
        # log_f.write('\t'.join(['_'.join(sorted(pair)), 'fail', str(ec), str(avg(sim))])+'\n')
        statistics['s2']['avg'][ec] += 1
        return avg(sim)
    if len(m_groups) >= 2: # majority group vote fail
        index_list = []
        for g in m_groups:
            index_list += g
        statistics['s1']['avg'][ec] += 1
        new_sim = avg([sim[i] for i in index_list])
        # log_f.write('\t'.join(['_'.join(sorted(pair)), 'fail', str(ec), str(new_sim)])+'\n')
        statistics['s2']['avg'][ec] += 1
        return new_sim

    new_list = m_groups[0] # majority group

    new_sim_list = [sim[s] for s in new_list]
    max_value = max(del_info.values())

    u_sim_list, m_sim_list = [], []
    for i in range(len(sim)):
        if i in new_list:
            u_sim_list.append(sim[i])
            m_sim_list.append(sim[i])
        else:
            u_sim_list.append(0)

    # it_info = {'max':0, 'min':0}
    # for i in range(len(sim)):
    #     if i not in new_list:
    #         if sim[i] >= max(m_sim_list):
    #             it_info['max'] += 1
    #         elif sim[i] <= min(m_sim_list):
    #             it_info['min'] += 1

    min_m, max_m, avg_m = min(new_sim_list), max(new_sim_list), avg(new_sim_list)
    u_sim_list += [min_m, max_m, avg_m]
    data = ['_'.join(sorted(pair)), 'min', str(ec), ] + [str(s) for s in u_sim_list]
    if ( del_info['max'] > 0 and del_info['min'] == 0 and del_info['other'] == 0) \
       or \
       ( del_info['max'] == max_value and del_info['min'] < max_value and del_info['other'] < max_value) :
    # if it_info['max'] < it_info['min']:
        statistics['s2']['min'][ec] += 1
        data[1] = 'min'
        # # log_f.write('\t'.join(data)+'\n')
        if ml:
            return mixture(weight[:nn], u_sim_list)
        else:
            return min_m

    if ( del_info['min'] > 0 and del_info['max'] == 0 and del_info['other'] == 0) \
       or \
       ( del_info['min'] == max_value) :
    # if it_info['max'] > it_info['min']:
        statistics['s2']['max'][ec] += 1
        data[1] = 'max'
        # log_f.write('\t'.join(data)+'\n')
        if ml:
            return mixture(weight[nn:nn*2], u_sim_list)
        else:
            return max_m

    statistics['s2']['avg'][ec] += 1
    data[1] = 'avg'
    # log_f.write('\t'.join(data)+'\n')
    if ml:
        return mixture(weight[nn*2:], u_sim_list)
    else:
        return avg_m


def get_major_group(major_num=4, group_distance=0.15):
    print (linkage_matrix)
    major_group = []
    for i in xrange(len(linkage_matrix)):
        for j in (0, 1):
            item = int(linkage_matrix[i][j])
            if item < len(linkage_matrix)+1: # leaf, not a cluster
                major_group.append(item)
        if len(major_group) >= major_num: break
    mm = [sim[i] for i in major_group]
    # print major_group, max(mm) - min(mm)
    # if len(major_group) >= major_num and max(mm) - min(mm) <= group_distance:
    if max(mm) - min(mm) <= group_distance:
        return major_group
    else:
        return False

# statistics = {
#     'max':[0, 0],
#     'min':[0, 0],
#     'avg':[0, 0],
#     'avg1':[0, 0],
# }

# majority group
def get_new_sim4():
    major_group = get_major_group(4, 0.15)
    if major_group == False: # No Majority Group
        statistics['avg1'][ec] += 1
        return avg(sim)
    major_sim = [sim[i] for i in major_group]
    min_m, max_m = min(major_sim), max(major_sim)
    info = {'max':0, 'min':0, 'other':0}
    for i in [v for v in range(len(sim)) if v not in major_group]:
        if sim[i] <= min_m:
            info['min'] += 1
        elif sim[i] >= max_m:
            info['max'] += 1
        else:
            info['other'] += 1
    if info['min'] != info['max'] and (info['min'] > 0 or info['max'] > 0):
        if info['min'] > info['max']:
            statistics['max'][ec] += 1
            # print 'max'
            return max_m
        else:
            # print 'min'
            statistics['min'][ec] += 1
            return min_m
    statistics['avg'][ec] += 1
    return max(major_sim)


# calculate the distance intra cluster (the average of different)
def get_average_distance(d):
    sum_d = 0.0
    for i in range(len(d)):
        for j in range(i+1, len(d)):
            sum_d += abs(float(d[i]-d[j]))
    return sum_d/len(d)


size = 0
# 类间使用最小距离(single)
linkage_method = 'single' # average complete
# linkage_method = 'average' # test

count = 0

plot = False
# plot = True
pair = []

sim, linkage_matrix, ec = [], [], 0

all_gene = {}

web = True
web = False

def reset():
    global statistics
    statistics = {
        's1':{
            'max':[0, 0],
            'min':[0, 0],
            'avg':[0, 0],
            },
        's2':{
            'max':[0, 0],
            'min':[0, 0],
            'avg':[0, 0],
            },
    }

train = True
train = False # test

# weight = [0.09090909090909091, 0.09090909090909091, 0.09090909090909091, 0.09090909090909091, 0.09090909090909091, 0.09090909090909091, 0.09090909090909091,]\
#         + [0, 0, 0, 0, 0, 1, 0,]\
#         + [0.09090909090909091, 0.09090909090909091, 0.09090909090909091, 0.09090909090909091, 0.09090909090909091, 0.09090909090909091, 0.09090909090909091]

# weight = [0.210909090909, 0, 0, 0, 0, 0, 0.595454545, 0.190909091, 0, 0, 0.002727273]\
#         +[0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0]\
#         +[0, 0, 0, 0, 0.02, 0, 0.976363636, 0, 0, 0, 0.003636364]

weight = [0.210909090909, 0, 0, 0, 0, 0.595454545, 0.190909091, 0, 0, 0.002727273]\
        +[0, 0, 0, 0, 0, 0, 0, 0, 1, 0]\
        +[0, 0, 0, 0.02, 0, 0.976363636, 0, 0, 0, 0.003636364]

# weight = [0.210909090909, 0, 0.595454545, 0.190909091, 0, 0, 0.002727273]\
#         +[0, 0, 0, 0, 0, 1, 0]\
#         +[0.02, 0, 0.976363636, 0, 0, 0, 0.003636364]


# print len(weight)

nn = int(len(weight) / 3)
print (nn - 3)

# log_f = open('/home/lhx/workspace/GO/data/new/cluster_pair_new.txt0000000000000000000000', 'w')
if train:
    gene_list_f = '../data/ec/tabu_train_gene.txt'
    # gene_list_f = '../data/yeast/pathway/gene_list.txt'
else:
    gene_list_f = '../data/ec/tabu_test_gene.txt'
    # gene_list_f = '../data/ec/tabu_test_gene.txt'
    # gene_list_f = '../data/ec/tabu_train_gene.txt'
    # gene_list_f = '../data/yeast/pathway/gene_list.txt'
    # log_f = open('/home/lhx/workspace/GO/data/new/cluster_test_pair_new.txt', 'w')

def run():
    global linkage_matrix, sim, ec, pair

    # print 'web is', web
    if not web and (ml or True):
        for l in open(gene_list_f):
            all_gene[l[:-1]] = None
        print ('0gene num is', len(all_gene))

    w = open(output_f, 'w')

    for l in open(input_f):
        d = l[:-1].split("\t")
        pair, sim = d[0:2], [float(x) for x in d[2:]]
        # if config.species == 'human' and config.ec =='ec' and not web and ( not all_gene.has_key(d[0]) or not all_gene.has_key(d[1])):
        #     continue
        if web:
            ec = 0
        else:
            ec = 0
            # ec = ec_value(pair[0], pair[1])
        # sim = [0.14, 0.12, 0.23, 0.48, 0.15, 0.51, 0.70, 0.20]
        size = len(sim)

        distance = []
        # 生成距离矩阵
        for i in range(size):
            for j in range(i+1, size):
                distance.append(abs(float(sim[j] - sim[i])))

        linkage_matrix = linkage(distance, method=linkage_method)

        if plot:
            plot_g(pair, sim, 'ec='+str(ec))
            count+=1
            if count >= 1000:
                pp.close()
                exit()
            continue
        # print clusters
        new_sim = get_new_sim3()
        # major_group = get_major_group()

        # print '\t'.join(pair+[str(new_sim)])
        w.write('\t'.join(pair+[str(new_sim)])+'\n')

    for k in statistics.keys():
        # print k, '\t', statistics[k][0], '\t',  statistics[k][1]
        print (k, '\t', '0', '\t', '1')
        for k1 in statistics[k].keys():
            print (k1, '\t', statistics[k][k1][0], '\t', statistics[k][k1][1])
    # pp.close()


if __name__ == '__main__':
    # 前k个参数是k个目标文件的路径，最后两个参数是输出文件路径和整合方法

    opts, args = getopt.getopt(sys.argv[1:], "o:i:")

    input_f = '../data/new/MF/all_rank.txt'
    output_f = '../data/new/MF/cluster.txt'

    for op, value in opts:
        if op == "-o":
            output_f = value
        elif op == "-i":
            input_f = value

    run()
