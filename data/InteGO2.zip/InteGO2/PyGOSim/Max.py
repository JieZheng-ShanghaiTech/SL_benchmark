#-*- coding: UTF-8 -*-

import os
import math
import cPickle
import networkx as nx

from Measure import *

'''
Measure Max
'''
class Max(Measure, GeneSim):
    def __init__(self, domain, paths):
        pass


