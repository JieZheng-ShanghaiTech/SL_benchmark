#-*- coding: UTF-8 -*-

import os
import math
import networkx as nx

from PyGOSim.Measure import *

'''
Measure TO
'''
class TO(Measure, GeneSim):
    def __init__(self, domain, species, paths):
        Measure.__init__(self, domain, species, paths)

    def run(self, g1, g2):
        g1_t = self.ann.get_terms_by_gene(g1)
        g2_t = self.ann.get_terms_by_gene(g2)
        intersection = g1_t & g2_t
        return len(intersection)

